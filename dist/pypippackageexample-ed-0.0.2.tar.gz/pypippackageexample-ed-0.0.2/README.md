# py-pip-package-example

Este es mi primer package de ejemplo en python

## correr setup
```
python setup.py sdist
```

## subir cambios
```
twine upload dist/*
```