
def sumaSimple(num, num2):
  return num + num2

def restSimple(num, num2):
  return num - num2

def mulSimple(num, num2):
  return num * num2