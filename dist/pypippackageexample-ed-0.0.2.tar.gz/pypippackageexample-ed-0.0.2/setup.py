
from setuptools import setup, find_packages

setup(
  name= 'pypippackageexample-ed',
  version='0.0.2',
  license='MIT',
  description='paquete de prueba para una clase de Udemy',
  author='Eduardo',
  packages=find_packages(),
  url='https://github.com/edvalenzuela/py-pip-package-example'
)